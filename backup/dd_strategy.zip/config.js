module.exports = {
    account: '2349070608423',
    password: '47d686928de69df0dbf7d413781beae3',
    nickname: '2349070608423',
    country: 'ng',
    platform: 21,
    deviceId: '35911dc91f11451110516e235be699aa'
};
