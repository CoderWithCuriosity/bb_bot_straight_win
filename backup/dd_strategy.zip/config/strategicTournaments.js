// config/strategicTournaments.js
module.exports = [
  { id: "vf:tournament:31867", name: "English League" },
  { id: "vf:tournament:14149", name: "League Mode" },
  { id: "vf:tournament:34616", name: "Bundesliga" },
];
