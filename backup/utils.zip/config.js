module.exports = {
    account: '2349070608423',
    password: '9f886460dc01f9ebc15db9b22edd1090',
    nickname: '2349070608423',
    country: 'ng',
    platform: 21,
    deviceId: '35911dc91f11451110516e235be699aa'
};
